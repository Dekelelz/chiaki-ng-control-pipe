cmake_minimum_required(VERSION 3.5)
project(NANOPB_CMAKE_SIMPLE C CXX)

set(CMAKE_MODULE_PATH ${CMAKE_CURRENT_SOURCE_DIR}/../../extra)
find_package(Nanopb REQUIRED COMPONENTS cpp-descriptors)

nanopb_generate_cpp(TARGET proto simple.proto)

set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -Wall -Werror -g -O0")

add_executable(simple simple.cpp)
target_link_libraries(simple proto)
